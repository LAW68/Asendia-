﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileReader.Model
{
    public class Parcel
    {
        public string ParcelNo;
        public List<ParcelItem> ParcelItems;
    }
}
