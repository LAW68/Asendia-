﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileReader.Model
{
    public class Order
    {
        public string OrderNo;
        public List<Consignment> Consignments;
    }
}
